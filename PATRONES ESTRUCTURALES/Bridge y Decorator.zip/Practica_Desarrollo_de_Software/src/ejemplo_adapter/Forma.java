package ejemplo_adapter;

interface Forma {
    double calcularArea();
}
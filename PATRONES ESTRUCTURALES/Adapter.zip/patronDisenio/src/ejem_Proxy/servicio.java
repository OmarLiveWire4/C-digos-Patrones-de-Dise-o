package ejem_Proxy;

public interface servicio {
    void realizarOperacion();
}

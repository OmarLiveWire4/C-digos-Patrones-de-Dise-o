package Ejemplo_01;
public interface Payment {
    public void pay();
}
